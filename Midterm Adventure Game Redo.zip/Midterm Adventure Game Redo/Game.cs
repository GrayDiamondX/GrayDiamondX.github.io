﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Midterm_Adventure_Game_Redo
{
    //set access modifier to public
    public class Game
    {
        //vars
        string playerName;
        
        //vars to store user input choices
        int choice1;
        int choice2;
        int choice3;

        //while loop
        //bool to control the while loop
        bool appRunning = true;

        //int to store user input for menu system
        int userMenuSelect;

        string playerInput;

        //bool to see if player gets a flashlight
        bool flashLight = false;
        bool stoneMineral = false;
        

        public void Run()
        {
            //fix spam when == true!!
            //fix why even it keeps asking for an input when I give it one
            while (appRunning == true)
            {
                //loop will run as long as value is true
                Console.WriteLine("Please select an option below.\n");
                Console.WriteLine("1) Intro, 2) First, 3) Last, 4) Credits, 5) Exit Game");
                //user input!
                string playerInput = Console.ReadLine();
                //convert a string into an int
                userMenuSelect = Convert.ToInt32(playerInput);

                //cashe user selection with conditional branch
                //switch method
                switch (userMenuSelect)
                {
                    //cases to match input
                    case 1:
                        Intro();
                        break;

                    case 2:
                        First();
                        break;

                    case 3:
                        Last();
                        break;

                    case 4:
                        Credits();
                        break;

                    case 5:
                        Exit();
                        break;
                }


            }

        }

        private void Credits()
        {
            Console.Clear();
            Console.WriteLine("\nExplore the Dungeon developed by Megan Oh - October 2, Fall 2024");

            Console.WriteLine("\nMenuSystemDemowCharacter made in class - Fall 2024");

            Console.WriteLine("\nAdoptAnInsectDemo made in class - Fall 2024");

            Console.WriteLine("");

            Console.WriteLine("");

            Console.WriteLine("");

            Console.WriteLine("\nTutor help from IAM - Ciarenn Hollis, Fall 2024");

            Console.WriteLine("\nIntro to C# - Item Shop by Michael Hadley - September 29, 2020 on YouTube");

            Console.WriteLine("\n\nPress Enter to continue...");
            Console.ReadLine();
            Console.Clear();
        }

        private void Exit()
        {
            System.Environment.Exit(0);
        }

        //content arrays to store narrative
        string[] areaArray = new string[10];

        //craft a method to populate the array
        public void areaPlaceArray()
        {
            areaArray[0] = "Do you 1) take them, or 2) leave them and keep walking.";

            areaArray[1] = "Do you 1) take in hopes of selling it, or 2) throw it as hard and far as you can?";

            areaArray[2] = "\nWho would you like to talk to?\n1) the first group, or 2) the second group?";

            areaArray[3] = "1) answer them truthfully, or 2) avoid the question and ask where you could find a shop.";

            areaArray[4] = "\n1) Yes, or 2) No.";

            areaArray[5] = "Do you 1) tell them Camillia sent you this way, or 2) you want to go home?";

            areaArray[6] = "";

            areaArray[7] = "";

            areaArray[8] = "";
        }



        //start the game
        public void Intro()
        {
            //story start!
            Console.WriteLine("\n...");
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();
            Console.Clear();


            Console.WriteLine("\nYou slowly open your eyes, a bright light shining from above you.");
            Console.WriteLine("You push yourself up, scanning the area.");
            Console.WriteLine("Nothing but darkness.");

            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("\nJust then, a bright blue window screen pops up!\nIt reads:\n");
            Console.WriteLine("‘Hello Adventurer! How do you fare?");
            Console.WriteLine("Welcome to the game, ‘Explore the Dungeon!’");
            Console.WriteLine("You may call me ‘Narrator’! I will be popping up every now and again to give you tips!' xP");
            Console.WriteLine("What is your name?’");

            Console.WriteLine("Please enter your name below:");
            playerName = Console.ReadLine();

            //try to make it that user HAS to enter a name?
            while (playerName == "")
            {
                Console.WriteLine("Please enter your name:");
                playerName = Console.ReadLine();
            }

            //clear the console
            Console.Clear();

            Console.WriteLine($"\n‘It's very nice to meet you, {playerName}!");
            Console.WriteLine("Now, I’m sure you’re wondering, ‘How did I get here?’");
            Console.WriteLine("Well, it looks like you fell from the top of the mountain.");
            Console.WriteLine("Good thing this bed of Golden Flowers broke your fall, huh?' :D");

            Console.WriteLine("‘Well, as the player, it's your job to explore! I will check back on you shortly!\nGood luck!’");

            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("\nThe window screen disappears, and a faint light emits from the ground, revealing a small dirt path.\nYou stand up, dusting off your clothes.");
            Console.WriteLine("Following the path, you see a few plants sticking out of the rocks.");

            //present array narrative!
            //don't forget to CALL the array method!
            areaPlaceArray();
            Console.WriteLine(areaArray[0]);


            //if and else if statement!
            //user choice!
            //use string playerInput.Console.ReadLine();
            //and then convert choice1 from an into into a string using ToInt32!
            string playerInput = Console.ReadLine();
            choice1 = Convert.ToInt32(playerInput);
            if (choice1 == 1)
            {
                Console.WriteLine("\nYou pull the plants out of the stone walls and floor and pocket it.");
                //find a way to add herbs
                // +3 herbs (int??)
                Console.ReadLine();
                Console.Clear();
            }

            else if (choice1 == 2)
            {
                Console.WriteLine("\nYou keep following the path.");
                Console.ReadLine();
                Console.Clear();
            }

            Console.WriteLine("\nIt feels like forever, you notice a light at the end of the tunnel.\nAs you get closer, you emerge from the opening to see...");
            Console.ReadLine();

            Console.WriteLine("A town?");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("\nThe blue screen pops up again with a ‘PING!’");
            Console.WriteLine($"‘Hey, {playerName}!");
            Console.WriteLine("Glad to see you made it out! It's a real maze in there!' xD");
            Console.WriteLine("As you can see, there is in fact a town!");
            Console.WriteLine("I’d like to welcome you to Snowd-erm… I mean Eimine! Pronounced [ey-mine].");
            Console.ReadLine();

            Console.WriteLine("\nA once bustling city of technology, escape, and freedom, is now just a suburban like town.\nVery peaceful, not much fuss or fighting, thankfully.’");
            Console.WriteLine("‘There are a few shops here, so feel free to look around!’");
            Console.WriteLine("Narrator then disappears again.");
            Console.ReadLine();
            Console.Clear();

            First();
        }

        public void First()
        {
            Console.Clear();
            Console.WriteLine("\nWalking away from the opening, you see the area is well lit with street lights, lanterns, and a few \nbioluminescent plants.");
            Console.WriteLine("While looking around, you don’t notice the rock sticking out of the ground,\nAnd fall and faceplant.");
            Console.ReadLine();

            Console.WriteLine("You take -1hp with an ‘oof’.");
            Console.ReadLine();

            Console.WriteLine("Sitting up, you take a look at the stone that you tripped on.\nIt's a medium sized piece of stone.\n");

            //don't forget to CALL the array method!
            areaPlaceArray();
            Console.WriteLine(areaArray[1]);

            //use string playerInput.Console.ReadLine();
            //and then convert choice1 from an into into a string using ToInt32!
            string playerInput = Console.ReadLine();
            choice1 = Convert.ToInt32(playerInput);
            if (choice1 == 1)
            {
                stoneMineral = true;
                Console.WriteLine("You pocket the stone, and get up to dust off your clothes once more, then continue to keep walking.");
                stoneMineral = true; //player now had mineral to sell
                Console.ReadLine();
                Console.Clear();
            }

            else if (choice1 == 2)
            {
                Console.WriteLine("You pull the stone out of the ground and chuck it into the air, far away from you.");
                Console.ReadLine();

                Console.WriteLine("A few seconds later, you hear, ‘Ouch! Where did that come from?’ from afar.");
                Console.ReadLine();

                Console.WriteLine("...");
                Console.ReadLine();
                Console.WriteLine("You keep walking.");

            }

            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("\nWalking through the town, you see many creatures chatting or shopping, but two groups catch your attention.");
            Console.WriteLine("In the first group, there is a person wearing a yellow puffer jacket with a black stripe \nand another with dual colored hair, one side light blue and the other a darker blue.");
            Console.ReadLine();

            Console.WriteLine("The second group seems to be a pair of skeletons. A short one wearing a blue hoodie and black basketball shorts, \nand the other, a taller figure with a red scarf and some kind of armor with big circle shoulder pads…?");
            Console.WriteLine("They’re arguing in front of a library, misspelled.");
            Console.ReadLine();
            Console.WriteLine("It reads ‘Librarby.’");
            Console.ReadLine();
            Console.Clear();

            areaPlaceArray();
            Console.WriteLine(areaArray[2]);
            FirstDialong();

            Console.Clear();
        }

        public void FirstDialong()
        {
            string playerInput = Console.ReadLine();
            choice1 = Convert.ToInt32(playerInput);
            if (choice1 == 1)
            {
                TalkingToCamillia();
            }

            else if (choice1 == 2)
            {
                //talk about the brothers
                //go to camillia
                Console.WriteLine("They seem to be a little busy.\nYou turn around and talk to the first group.");
                Console.ReadLine();
                Console.Clear();
                TalkingToCamillia();
            }
        }

        public void TalkingToCamillia()
        {
            Console.WriteLine("\nWalking up to the first group, the one wearing the yellow jacket notices you.");

            //this is where I'm going to try and instantiate an NPC hopefully it goes well ;-;
            //first, instantiate Camillia
            Camillia Character1 = new Camillia("Camillia", "Bee hybrid", "an Adventurer!");
            Character1.Introduction();

            SecondDialog();
        }

        public void SecondDialog()
        {
            Console.WriteLine(areaArray[3]);
            string playerInput = Console.ReadLine();
            choice2 = Convert.ToInt32(playerInput);
            if (choice2 == 1)
            {
                Console.Clear();
                //answer truthfully
                Console.WriteLine("\n‘Oh, are you alright? How did you even get up there? Oh, anyways, could you do me a favor? \nYoori and I have all these herbs but we don’t need them right now, do you want them?’");
                //then the About method

                ThirdDialog();
            }

            else if (choice2 == 2)
            {
                Console.Clear();
                //avoid question and ask for shop
                Console.WriteLine("\nYoori places a hand on Camillia’s shoulder. ‘Ah, I’m sorry, I don’t mean to pry. Anyways, could you do me a favor? \nYoori and I have a few stones we mined, but we don’t need them right now, do you want them?’");

                ThirdDialog();
            }

        }

        public void ThirdDialog()
        {
            areaPlaceArray();
            Console.WriteLine(areaArray[4]);
            string playerInput = Console.ReadLine();
            choice3 = Convert.ToInt32(playerInput);
            if (choice3 == 1)
            {
                //yes
                Console.WriteLine("\nYou nod.");
                Console.WriteLine("You ask where the nearest store to sell your items is.\nCamellia points to a light blue building, ‘That’s Ella’s shop, she can help you.’");
                Console.WriteLine("You smile and thank them.");
                Console.ReadLine();
                Console.WriteLine("Yoori hands you the items. ‘Camillia and I need to go soon, we have another mission. If you’re looking for a way out, \nkeep walking down this main path. \nIt’ll lead you to an abandoned zone, but it's not dangerous. Good luck.’");
                Console.ReadLine();
                //player1.Inventory

                Store();
            }

            else if (choice3 == 2)
            {
                //no
                Console.WriteLine("You shake your nod to decline, and Camillia smiles sadly.");
                Console.ReadLine();
                Console.WriteLine("\nWith that, Camillia and Yoori leave.");
                Console.ReadLine();

                Last();
            }

            

        }

        public void Store()
        {
            //I'll be honest, I could not figure out how to do inventory add and remove, so I typed everything out manually
            //I'm so tired this is my limit ;-;
            //Interaction with Ella
            Console.Clear();
            Console.WriteLine("\nYou walk to the store, and as you push open the door, a little bell hanging above it chimes.");
            Console.WriteLine("A lady from the back walks to the counter, 'Hello there! I’m Ella, how can I help you?'");
            Console.WriteLine("You say you want to sell a few things.");
            Console.ReadLine();

            Console.WriteLine("'Alright, what do you have for me?'");

            if (stoneMineral == true)
            {
                Console.WriteLine("\nYou take out your plants and rock. She inspects them and smiles.");
                Console.WriteLine("‘Herbs are 3 silver, and minerals are 2 silver. Here, you have 12 herbs and 1 rock, \nso that will be a total of 38 silver.’");
                Console.WriteLine("She takes the items and counts out 38 silver, pushing the pile towards you.");
                Console.ReadLine();

                Console.WriteLine("‘Is there anything else I can help you with?’\n");
                Console.WriteLine("You ask if you can buy a flashlight and a bandaid. Ella nods and grabs the items you’ve requested.");
                flashLight = true;

                Console.WriteLine("‘That will be 12 silver for the flashlight, batteries included, and 2 silver for the bandaid.’");
                Console.WriteLine("\nElla bags up the rest of your silver into a little bag and hands you your items.");
                Console.ReadLine();

                Console.WriteLine("You have 24 silver left.");
                Console.ReadLine();
                Console.Clear();
            }

            else if (stoneMineral == false)
            {
                Console.WriteLine("\nYou take out your plants. She inspects them and smiles.");
                Console.WriteLine("‘Herbs are 3 silver. You have 12 herbs \nso that will be a total of 36 silver.’");
                Console.WriteLine("She takes the items and counts out 36 silver, pushing the pile towards you.");
                Console.ReadLine();

                Console.WriteLine("‘Is there anything else I can help you with?’");
                Console.WriteLine("You ask if you can buy a bandaid. Ella nods and grabs the items you’ve requested.");
                flashLight = false;

                Console.WriteLine("‘That will be 2 silver for the bandaid.’");
                Console.WriteLine("Ella bags up the rest of your silver into a little bag and hands you your items.");
                Console.ReadLine();

                Console.WriteLine("You have 34 silver left.");
                Console.ReadLine();
                Console.Clear();
            }

            Console.WriteLine("\nYou use the bandaid and gain +1hp!");
            Console.WriteLine("You tuck the bag away and thank Ella.");
            Console.WriteLine("You leave the store.");
            Console.ReadLine();
            //clear
            Console.Clear();

            Last();
        }

        public void Last() 
        {
            //Second phase of the story!

            Console.Clear();
            Console.WriteLine("\nFollowing the path Yoori pointed to, you hear the chatter of the folks behind you slowly fade into the distance.");
            Console.WriteLine("The only thing you can hear now is your own footsteps.");
            Console.ReadLine();

            Console.WriteLine("The light of the market fades, leaving you in darkness.");
            if (flashLight == true)
            {
                Console.WriteLine("Narrator pops up again, the box’s glow as well as your flashlight illuminating your path.");
                Console.WriteLine("You can see the walls clearly, dripstone, small patches of moss and small puddles of water. \nYou avoid stepping to the puddles.");
                Console.ReadLine();
            }

            else if (flashLight == false)
            {
                Console.WriteLine("Narrator pops up again, the box’s glow illuminating your path.");
                Console.WriteLine("You can’t see much, just the faintest bits of stone.");
                Console.WriteLine("However, you step into lots of puddles, getting your socks wet.");
                Console.ReadLine();
            }

            Console.WriteLine("As you walk in darkness, you feel like something is watching you.");
            Console.WriteLine("‘Nothing is here to hurt you. As your guide, I don’t sense any danger. ^^’ Narrator says.");
            Console.WriteLine("Taking their words, you trudge on.");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("\nYou start to hear...");
            Console.ReadLine();
            Console.WriteLine("Dripping water?");
            Console.ReadLine();

            Console.WriteLine("The sound of dirt under your feet starts to fade and the sound of metal replaces it.");
            Console.WriteLine("Light slowly fills the room as blue light shifts around you.");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("\nYou now find yourself standing in the middle of an underwater tunnel.");
            Console.WriteLine("You look through the glass, a city full of lights. Skyscrapers taller than the kelp beds, pavilions, theaters, \napartment blocks, casinos; a whole city underwater.");
            Console.WriteLine("You can also see some statues of men decorating the building walls as if they were columns.");
            Console.ReadLine();
            Console.WriteLine("But, you also notice, despite the lights, there are no other movements. ");
            Console.ReadLine();
            Console.WriteLine("At least, living movements.");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("\nWalking to the end of the tunnel, a large metal door blocks your path. \nNot knowing how to open it, you just stare at it.");
            Console.ReadLine();
            Console.WriteLine("Suddenly, the door slides up, and on the other side, a figure covered with a dirty, tattered tan cloak.");
            Console.WriteLine("You jump back, but the figure stays in place.");
            Console.WriteLine("Slowly, they raise their hand, shiny and blue with a scratched symbol in the shape of a diamond on the back \nof their hand, and brings it up to their cloak. Pulling the cloak back, you see a human...?\"");
            Console.ReadLine();

            Console.WriteLine("They look human, this being has fair skin, brown hair with blue streaks, and a neutral face, \nbut strangely enough, they have blue eyes that look like jewels.");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("\n'What are you doing here?' They say, their voice hoarse and dry sounding.");
            Console.ReadLine();

            areaPlaceArray();
            Console.WriteLine(areaArray[5]);

            string playerInput = Console.ReadLine();
            choice1 = Convert.ToInt32(playerInput);
            if (choice1 == 1)
            {
                Console.WriteLine("\nThey nod. 'You’ve met Camillia and Yoori. They have good hearts, but terrible directions. \nThis is not the place to be.'");
                Console.ReadLine();
            }

            else if (choice1 == 2)
            {
                Console.WriteLine("\n'This is a dangerous place. Not one you, especially, should go through. \nYou are too weak and young.'");
                Console.ReadLine();
            }

            Console.WriteLine("They take your wrist. Their hand is metallic and cold, and they drag you away from the tunnel door. \nLeading you back into the dark, you look up at them, their eyes seemingly glowing in the darkness.");
            Console.WriteLine("The two of you walk back the way you came, but make a right turn. \n\n'Watch your step.' They say. You can feel the ground beneath you start to incline. You’re going up a slope.");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("\nJust above, you see light. Bright, white light of the sun. You both emerge from a large cave opening. \nYou see a lush green forest below and the lake you saw from before.");
            Console.WriteLine("\nYou turn to the stranger and thank them.");
            Console.ReadLine();
            Console.WriteLine("‘It's not a problem. There is a path that leads you back to the nearest village. \nI hope to never see you in that tunnel again.’");
            Console.WriteLine("They turn back to the cave, walking half way in, before turning back to you.");
            Console.ReadLine();

            Dia Character2 = new Dia("Dia", "Gem droid", "Wanderer");
            Character2.Introduction();
            Console.WriteLine("Their eyes shined like diamonds.");
            Console.WriteLine("They turn away again and continue walking, their figure disappearing back into the darkness.");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("\nNarrator appears.");
            Console.WriteLine($"{playerName}! You’ve made it out of Mt. Kale!");
            Console.WriteLine("Thank you for playing the game! I hope you had fun!");
            Console.WriteLine("This... will be our final conversation, until we meet again.");
            Console.WriteLine("Use this path to come back soon!");
            Console.WriteLine("I’ll miss you! Heehee >3<");
            Console.ReadLine();
            Console.WriteLine($"Thank you, {playerName}! For playing ‘Escape the Dungeon!'");
            Console.WriteLine("See you next time, Adventurer!’");
            Console.WriteLine("With that, Narrator disappears and you look beyond the first below, ready to start your new adventure.");
            Console.ReadLine();

            Console.WriteLine("Please Enter to Exit Game...");    
        }

        


    }
}
