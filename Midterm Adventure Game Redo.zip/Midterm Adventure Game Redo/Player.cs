﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midterm_Adventure_Game_Redo
{
    //modifier to public
    public class Player
    {
        //vars
        public string playerName;

        //craft a constructor
        public Player(string _playerName)
        {
            //marry the input to local var
            playerName = _playerName;
        }
        

    }
}
