﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midterm_Adventure_Game_Redo
{
    //set modifier to public
    public class Dia : Character
    {
        //another NPC
        //modify the constructor to marry up
        //with the overloaded constructor of the base class
        public Dia(string _charName, string _speices, string _occupation) : base(_charName, _speices, _occupation)
        {

            //custom values
            charName = "Dia";
            speices = "Gem droid";
            occupation = "Wanderer.";

        }

        public void Introduction()
        {
            Console.WriteLine($"\n'My name is {charName}, I'm a {speices} {occupation} Safe travels.'");
            Console.ReadLine();

        }
    }
}
