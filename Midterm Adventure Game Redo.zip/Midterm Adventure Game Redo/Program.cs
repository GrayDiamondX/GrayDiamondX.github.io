﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midterm_Adventure_Game_Redo
{
    //set access modifier to public
    public class Program
    {
        static void Main()
        {
            Game myGame1 = new Game();

            myGame1.Run();

            myGame1.Intro();

            myGame1.First();

            myGame1.Last();


        }
    }
}
