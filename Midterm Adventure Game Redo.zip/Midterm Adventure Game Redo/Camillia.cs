﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midterm_Adventure_Game_Redo
{
    //set access modifier to public
    public class Camillia : Character
    {
        //modify the constructor to marry up
        //with the overloaded constructor of the base class
        public Camillia(string _charName, string _speices, string _occupation) : base(_charName, _speices, _occupation)
        {
            
            //custom values
            charName = "Camillia";
            speices = "Bee hybrid";
            occupation = "Adventurers!";

        }

        public void Introduction()
        {
            Console.WriteLine($"\n'Oh, hello! I'm {charName}, a {speices}. And this is my friend Yoori the Shapeshifter! \nWe're {occupation}! What brings you here?'");
            Console.ReadLine();
        }
    }
}
