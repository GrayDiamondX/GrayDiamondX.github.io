﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Midterm_Adventure_Game_Redo
{
    //modifier to public
    public class Character
    {
        //use Inheritance for characters
        //base the code off of AdoptAnInsect
        public string charName;
        public string speices;
        public string occupation;
        //I think its like this?

        //make a constructor three input parameters
        //provided by the user: name, speices, and occupation
        //somehow OTL
        public Character(string _charName, string _speices, string _occupation)
        {
            //marry the input parameters to the local vars
            charName = _charName;
            speices = _speices;
            occupation = _occupation;

        }
        public Character()
        {
            //set default values
            charName = "Ella";
            speices = "Human";
            occupation = "an Artist";
        }

        //writing About the NPCs
        //the default will be the Shopkeeper I guess?
        public void AboutCharacter()
        {
            Console.WriteLine($"Hello! I'm {charName} the {speices}, and I'm {occupation}.");
            Console.ReadLine();
            //Console.Clear();
        }

    }
}
